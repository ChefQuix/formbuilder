<template>
  <div>
    <div class="row">
      <div class="col-8">
        <h2>Form</h2>
        <component v-for="(item,index) in config.components"
          :key="'form' + index"
          :is="item.type"
          :options="item.options"
          :value="item.value"
          @emitValue="setValue(index,item.type,$event)"
        >
        </component>
      </div>
      <div class="col-4">
        <h2>Admin</h2>
        <div class="row mb-4">
          <div class="col-6">
            <button type="button" class="btn btn-secondary" @click="addFormElement('FullName')">Add FullName</button>
          </div>
          <div class="col-6">
            <button type="button" class="btn btn-secondary" @click="addFormElement('TextInput')">Add TextInput</button>
          </div>
        </div>
        <component v-for="(item,jndex) in config.components"
          :key="'admin' + jndex"
          :is="item.type"
          :options="item.options"
          :value="item.options"
          :admin="true"
          @adminOptions="setAdmin(jndex,$event)"
        >
          <div class="row">
            <div class="col-8">
              <h3>{{ item.type }}</h3>
            </div>
            <div class="col-4">
              <button type="button" class="btn btn-outline-secondary" @click="removeAdmin(jndex)">remove?</button>
            </div>
          </div>
         </component>
       </div>
    </div>
  </div>
</template>

<script>
const defaultConfig = {
        permitType: 1,
        pages: [ ],
        components: [
          {
            type: "TextInput",
            options: {
              label: "Email",
              description: "This is an email address",
              columnName: "amanda-100"
            },
            value: { }
          },
          {
            type: "TextInput",
            options: {
              label: "City",
              description: "Where were you born?",
              columnName: "amanda-101"
            },
            value: { }
          },
          {
            type: "FullName",
            options: { columnName: "amanda-102" },
            value: { }
          }
        ]
      };

import TextInput from '@/components/FormElements/TextInput.vue';
import FullName from '@/components/FormElements/FullName.vue';

export default {
  components: { TextInput, FullName },

  data() {
    return {
      config: defaultConfig,
      FormData: []
    }
  },

  created() {
    this.config.components.forEach(() => {
      this.FormData.push({});
    });
  },

  methods: {
    setValue(index,field,value) {
      value.type=field;
      this.FormData.splice(index,1,value);
    },
    setAdmin(index,value) {
      //this.config.components[index].config = value;
      const updatedComponent = { ...this.config.components[index], options: { ...value } };
      this.config.components.splice(index, 1, updatedComponent);
    },
    removeAdmin(index) {
      this.config.components.splice(index,1);
    },
    addFormElement(type) {
      this.FormData.push({});
      this.config.components.push({type: type, config: { columnName: "", label: "", description: ""}})
    }
  },

  computed: {

    valid() {
      return this.FormData.reduce((prev,curr) => (prev && curr.isValid), true );
    }
  }

}
</script>

<style>

</style>
