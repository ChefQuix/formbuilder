<template>
  <FormBuilder></FormBuilder>
</template>

<script>
import FormBuilder from './components/FormBuilder.vue'

export default {
  name: 'App',
  components: {
    FormBuilder
  }
}
</script>

<style>
</style>
