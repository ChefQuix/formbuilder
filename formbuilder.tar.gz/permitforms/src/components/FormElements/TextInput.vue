<template>
  <div>
    <div v-if="admin">
      <slot></slot>
      <div class="form-group">
        <label for="labelid">Label</label>
        <input v-model="adminOptions.label" class="form-control" id="labelid">
      </div>
      <div class="form-group">
        <label for="descriptionId">Description</label>
        <input v-model="adminOptions.description" class="form-control" id="description">
      </div>
      <div class="form-group">
        <label for="columnNameId">Column Name</label>
        <input v-model="adminOptions.columnName" class="form-control" id="columnNameId">
      </div>
    </div>
    <div class="form-group" v-else>
      <label :for=labelFor>{{ options.label }}</label>
      <input v-model="textInput" type="text" class="form-control" :id=labelFor>
      <small class="form-text text-muted">
        {{ options.description }}
      </small>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    value: {
      type: Object,
      default() {
        return {}
      },
    },
    options: {
      type: Object,
      default() {
        return {
          label: "",
          description: "",
          columnName: "",
        }
      }
    },
    admin: {
      type: Boolean,
      default: false,
    }
  },

  data() {
    return {
      textInput: "",
      adminOptions: {
          label: "",
          description: "",
          columnName: "",
      }
    }
  },
  created() {
    console.log(this.options,this.value);
    if (this.admin) {
      this.adminOptions.label = (this.value.label) ? this.value.label : "";
      this.adminOptions.description = (this.value.description) ? this.value.description : "";
      this.adminOptions.columnName = (this.value.columnName) ? this.value.columnName : "";
    }
  },

  computed: {
    labelFor() {
      if (this.options.label) {
        return this.options.label + '-for'.replace(/[^a-z-0-9]/gi, '').toLowerCase();
      }
      return '';
    },
    isValid() {
      return (this.textInput.length > 0);
    }
  },

  watch: {
    textInput() {
      this.$emit('emitValue',{ value: this.textInput, isValid: this.isValid});
    },

    options: {
      handler(newVal) {
        console.log('newText',newVal)
      },
      deep: true,
    },

    adminOptions: {
      handler(newVal) {
        this.$emit('adminOptions', newVal)
      },
      deep: true,
    }
  }

}
</script>

<style>

</style>
