<template>
  <div class="form-group">
    <label>{{ type }}</label>

  </div>
</template>

<script>
export default {
  props: ['type','options','value']

}
</script>

<style>

</style>
