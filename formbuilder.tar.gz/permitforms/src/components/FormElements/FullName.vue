<template>
  <div>
    <div v-if="admin">
      <slot></slot>
      <div class="form-group">
        <label for="columnNameId">Column Name</label>
        <input v-model="adminOptions.columnName" class="form-control" id="columnNameId">
      </div>
    </div>
    <div v-else class="form-group">
      <div class="row">
        <div class="col-6">
          <label for="firstNameLabel">First name</label>
          <input type="text" v-model="firstName" class="form-control" id="firstNameLabel">
          <small class="form-text text-muted">
            First or given name
          </small>
        </div>
        <div class="col-6">
          <label for="LastNameLabel">Last name</label>
          <input type="text" v-model="lastName" class="form-control" id="lastNameLabel">
          <small class="form-text text-muted">
            Last or family name
          </small>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    value: {
      type: Object,
      default() {
        return {}
      },
    },
    options: {
      type: Object,
      default() {
        return {
          columnName: "",
        }
      }
    },
    admin: {
      type: Boolean,
      default: false,
    }
  },

  created() {
    console.log(this.options,this.value);
    if (this.admin) {
      this.adminOptions.columnName = (this.value.columnName) ? this.value.columnName : "";
    }
  },

  data() {
    return {
      firstName: "",
      lastName: "",
      adminOptions: {
        columnName: "",
      }
    }
  },

  computed: {
    fullName() {
      return this.firstName + ' ' + this.lastName;
    },
    isValid() {
      return (this.firstName.length > 0 && this.lastName.length > 0);
    }
  },

  watch: {
    value() {
      this.$emit('emitValue',{ valid: this.isValid, value: this.fullName});
    },
    adminOptions() {
      this.$emit('adminOptions', this.adminOptions )
    }
  }

}
</script>

<style>

</style>
